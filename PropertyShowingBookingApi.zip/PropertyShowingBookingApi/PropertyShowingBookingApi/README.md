# Property Showing Booking API

ASP.NET Core Web API on .NET 8 with Entity Framework Core and **SQL Server** persistence.

## Prerequisites
- .NET 8 SDK
- SQL Server (LocalDB, SQL Express, Developer or Docker)
- Visual Studio 2022 or VS Code

## Configure the database
Edit `src/PropertyShowingBookingApi/appsettings.json` and set `ConnectionStrings:DefaultConnection`.
Examples:

Windows SQL Express:
`Server=.\SQLEXPRESS;Database=PropertyShowingBookingDb;Trusted_Connection=True;TrustServerCertificate=True;`

LocalDB:
`Server=(localdb)\MSSQLLocalDB;Database=PropertyShowingBookingDb;Trusted_Connection=True;TrustServerCertificate=True;`

SQL Server username/password:
`Server=localhost,1433;Database=PropertyShowingBookingDb;User Id=sa;Password=YourStrongPassword;TrustServerCertificate=True;`

## Run
From the solution directory:

```bash
dotnet restore
dotnet run --project src/PropertyShowingBookingApi
```

Open the Swagger URL printed in the console (usually `/swagger`).

Create the database schema using EF Core migrations. Install the EF CLI if needed:
```bash
dotnet tool install --global dotnet-ef --version 8.0.11
dotnet ef migrations add InitialCreate --project src/PropertyShowingBookingApi
dotnet ef database update --project src/PropertyShowingBookingApi
```

## Run tests
```bash
dotnet test
```
Tests use EF Core InMemory so they do not require a running SQL Server.

## Endpoints
- `POST /slots`
- `GET /slots?propertyId=1&from=2026-12-01T00:00:00Z&to=2026-12-31T23:59:59Z&page=1&pageSize=20`
- `POST /slots/{id}/bookings`
- `POST /bookings/{id}/transitions`
- `GET /bookings/{id}/history`

All date/time inputs should be supplied as UTC ISO-8601 values, e.g. `2026-12-01T10:00:00Z`.

### Example requests

Create slot:
```json
{
  "propertyId": 100,
  "startsAt": "2026-12-01T10:00:00Z",
  "durationMinutes": 30,
  "capacity": 10
}
```

Create booking:
```json
{
  "renterEmail": "renter@example.com",
  "partySize": 2
}
```

Cancel booking:
```json
{
  "to": "Cancelled",
  "reason": "Plans changed",
  "actor": "renter"
}
```

## Main design decisions
- Controller layer handles HTTP and status codes; `BookingService` contains booking and transition business rules.
- EF Core entities model slots, bookings and append-only booking history.
- A filtered unique SQL Server index prevents duplicate active bookings for the same normalized renter email and slot.
- Booking creation uses a SQL Server transaction with serializable isolation and takes an update/hold lock on the slot row. This serializes booking attempts for one slot before calculating remaining seats, preventing simultaneous requests from overbooking.
- `Cancelled`, `Attended` and `NoShow` are terminal because transitions only accept a current `Confirmed` booking.
- API validation uses data annotations and controller checks. Invalid input returns 400, missing resources 404 and disallowed booking actions 409.

## What I would do with more time
- Add integration tests against SQL Server (including parallel requests to prove no overbooking).
- Add authentication/authorization so owner and renter actors are derived from the authenticated user rather than trusted request data.
- Add explicit time-zone policy, structured error middleware, logging and API versioning.
- Add migration files to source control and CI build/test workflow.
- Add tests for all transition permutations, filtering and pagination.

