using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Data;
using PropertyShowingBookingApi.DTOs;
using PropertyShowingBookingApi.Models;
using PropertyShowingBookingApi.Services;

namespace PropertyShowingBookingApi.Controllers;

[ApiController]
[Route("slots")]
public class SlotsController(ApplicationDbContext db, BookingService bookingService) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateSlotDto request, CancellationToken ct)
    {
        if (request.StartsAt <= DateTime.UtcNow)
            return BadRequest(new { error = "startsAt must be in the future (UTC)." });

        var slot = new ShowingSlot
        {
            PropertyId = request.PropertyId,
            StartsAt = DateTime.SpecifyKind(request.StartsAt, DateTimeKind.Utc),
            DurationMinutes = request.DurationMinutes,
            Capacity = request.Capacity
        };
        db.ShowingSlots.Add(slot);
        await db.SaveChangesAsync(ct);
        return Created($"/slots/{slot.Id}", new { slot.Id, slot.PropertyId, slot.StartsAt, slot.DurationMinutes, slot.Capacity });
    }

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] SlotQueryDto query, CancellationToken ct)
    {
        if (query.Page < 1 || query.PageSize < 1 || query.PageSize > 100)
            return BadRequest(new { error = "page must be >= 1 and pageSize must be between 1 and 100." });
        if (query.From.HasValue && query.To.HasValue && query.From > query.To)
            return BadRequest(new { error = "from cannot be later than to." });

        var slots = db.ShowingSlots.AsNoTracking().AsQueryable();
        if (query.PropertyId.HasValue) slots = slots.Where(s => s.PropertyId == query.PropertyId);
        if (query.From.HasValue) slots = slots.Where(s => s.StartsAt >= query.From);
        if (query.To.HasValue) slots = slots.Where(s => s.StartsAt <= query.To);

        var total = await slots.CountAsync(ct);
        var items = await slots.OrderBy(s => s.StartsAt)
            .Skip((query.Page - 1) * query.PageSize).Take(query.PageSize)
            .Select(s => new
            {
                s.Id, s.PropertyId, s.StartsAt, s.DurationMinutes, s.Capacity,
                SeatsRemaining = s.Capacity - s.Bookings
                    .Where(b => b.Status == Enums.BookingStatus.Confirmed).Sum(b => (int?)b.PartySize) ?? s.Capacity
            }).ToListAsync(ct);

        return Ok(new { query.Page, query.PageSize, TotalCount = total, Items = items });
    }

    [HttpPost("{id:int}/bookings")]
    public async Task<IActionResult> Book(int id, [FromBody] CreateBookingDto request, CancellationToken ct)
    {
        try
        {
            var booking = await bookingService.CreateBookingAsync(id, request, ct);
            return Created($"/bookings/{booking.Id}", new
            {
                booking.Id, booking.SlotId, booking.RenterEmail, booking.PartySize,
                Status = booking.Status.ToString(), booking.CreatedAt
            });
        }
        catch (KeyNotFoundException ex) { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new { error = ex.Message }); }
    }
}
