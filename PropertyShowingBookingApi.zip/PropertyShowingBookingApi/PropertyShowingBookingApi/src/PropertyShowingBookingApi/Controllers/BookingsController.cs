using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Data;
using PropertyShowingBookingApi.DTOs;
using PropertyShowingBookingApi.Services;

namespace PropertyShowingBookingApi.Controllers;

[ApiController]
[Route("bookings")]
public class BookingsController(ApplicationDbContext db, BookingService service) : ControllerBase
{
    [HttpPost("{id:int}/transitions")]
    public async Task<IActionResult> Transition(int id, [FromBody] TransitionBookingDto request, CancellationToken ct)
    {
        try
        {
            var booking = await service.TransitionAsync(id, request, ct);
            return Ok(new { booking.Id, Status = booking.Status.ToString() });
        }
        catch (KeyNotFoundException ex) { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new { error = ex.Message }); }
    }

    [HttpGet("{id:int}/history")]
    public async Task<IActionResult> History(int id, CancellationToken ct)
    {
        var exists = await db.Bookings.AnyAsync(b => b.Id == id, ct);
        if (!exists) return NotFound(new { error = "Booking was not found." });

        var history = await db.BookingHistories.AsNoTracking()
            .Where(h => h.BookingId == id)
            .OrderBy(h => h.ChangedAt)
            .Select(h => new { h.FromStatus, h.ToStatus, h.ChangedAt, h.Actor, h.Reason })
            .ToListAsync(ct);
        return Ok(history);
    }
}
