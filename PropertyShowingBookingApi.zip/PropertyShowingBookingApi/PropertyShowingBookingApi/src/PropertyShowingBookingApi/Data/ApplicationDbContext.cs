using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Models;

namespace PropertyShowingBookingApi.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<ShowingSlot> ShowingSlots => Set<ShowingSlot>();
    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<BookingHistory> BookingHistories => Set<BookingHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ShowingSlot>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.StartsAt).IsRequired();
            entity.HasMany(x => x.Bookings).WithOne(x => x.Slot).HasForeignKey(x => x.SlotId);
        });

        modelBuilder.Entity<Booking>(entity =>
        {
            entity.Property(x => x.RenterEmail).HasMaxLength(255).IsRequired();
            entity.HasIndex(x => new { x.SlotId, x.RenterEmail })
                .IsUnique().HasFilter("[Status] = 1");
            entity.HasIndex(x => new { x.SlotId, x.Status });
            entity.HasMany(x => x.History).WithOne(x => x.Booking).HasForeignKey(x => x.BookingId);
        });
    }
}
