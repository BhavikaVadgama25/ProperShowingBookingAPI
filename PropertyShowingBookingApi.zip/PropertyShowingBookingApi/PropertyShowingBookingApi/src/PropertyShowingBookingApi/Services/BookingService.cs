using System.Data;
using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Data;
using PropertyShowingBookingApi.DTOs;
using PropertyShowingBookingApi.Enums;
using PropertyShowingBookingApi.Models;

namespace PropertyShowingBookingApi.Services;

public class BookingService(ApplicationDbContext db)
{
    public async Task<Booking> CreateBookingAsync(int slotId, CreateBookingDto request, CancellationToken ct)
    {
        // Lock the parent slot row so all booking attempts for this slot are serialized.
        await using var transaction = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable, ct);
        var slot = await db.ShowingSlots
            .FromSqlInterpolated($"SELECT * FROM ShowingSlots WITH (UPDLOCK, HOLDLOCK) WHERE Id = {slotId}")
            .SingleOrDefaultAsync(ct);

        if (slot is null) throw new KeyNotFoundException("Showing slot was not found.");
        if (slot.StartsAt <= DateTime.UtcNow) throw new InvalidOperationException("Bookings are closed because the slot has started.");

        var email = request.RenterEmail.Trim().ToLowerInvariant();
        var existing = await db.Bookings.AnyAsync(b =>
            b.SlotId == slotId && b.RenterEmail == email && b.Status == BookingStatus.Confirmed, ct);
        if (existing) throw new InvalidOperationException("Renter already has an active booking for this slot.");

        var bookedSeats = await db.Bookings
            .Where(b => b.SlotId == slotId && b.Status == BookingStatus.Confirmed)
            .SumAsync(b => (int?)b.PartySize, ct) ?? 0;

        if (bookedSeats + request.PartySize > slot.Capacity)
            throw new InvalidOperationException("Not enough seats remaining for this party.");

        var booking = new Booking
        {
            SlotId = slotId,
            RenterEmail = email,
            PartySize = request.PartySize,
            Status = BookingStatus.Confirmed,
            CreatedAt = DateTime.UtcNow
        };
        booking.History.Add(new BookingHistory
        {
            FromStatus = "",
            ToStatus = BookingStatus.Confirmed.ToString(),
            Actor = "renter",
            Reason = "Booking created",
            ChangedAt = DateTime.UtcNow
        });

        db.Bookings.Add(booking);
        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
        return booking;
    }

    public async Task<Booking> TransitionAsync(int bookingId, TransitionBookingDto request, CancellationToken ct)
    {
        var booking = await db.Bookings.Include(b => b.Slot).FirstOrDefaultAsync(b => b.Id == bookingId, ct);
        if (booking is null) throw new KeyNotFoundException("Booking was not found.");

        if (!Enum.TryParse<BookingStatus>(request.To, true, out var target))
            throw new InvalidOperationException("Unknown target booking status.");

        if (booking.Status != BookingStatus.Confirmed)
            throw new InvalidOperationException("Only Confirmed bookings can transition.");

        var actor = request.Actor.Trim().ToLowerInvariant();
        if (target == BookingStatus.Cancelled)
        {
            if (actor is not ("owner" or "renter"))
                throw new InvalidOperationException("Only owner or renter can cancel a booking.");
            if (booking.Slot.StartsAt <= DateTime.UtcNow)
                throw new InvalidOperationException("A booking can only be cancelled before the slot starts.");
        }
        else if (target is BookingStatus.Attended or BookingStatus.NoShow)
        {
            if (actor != "owner")
                throw new InvalidOperationException("Only the owner can mark a booking Attended or NoShow.");
            if (booking.Slot.StartsAt > DateTime.UtcNow)
                throw new InvalidOperationException("Attended or NoShow can only be set after the slot starts.");
        }
        else
        {
            throw new InvalidOperationException("This transition is not allowed.");
        }

        var previous = booking.Status;
        booking.Status = target;
        booking.History.Add(new BookingHistory
        {
            FromStatus = previous.ToString(),
            ToStatus = target.ToString(),
            Actor = actor,
            Reason = request.Reason,
            ChangedAt = DateTime.UtcNow
        });

        await db.SaveChangesAsync(ct);
        return booking;
    }
}
