using System.ComponentModel.DataAnnotations;

namespace PropertyShowingBookingApi.DTOs;

public class CreateBookingDto
{
    [Required, EmailAddress, MaxLength(255)] public string RenterEmail { get; set; } = "";
    [Range(1, 6)] public int PartySize { get; set; }
}
