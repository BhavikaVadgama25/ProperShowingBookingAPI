using System.ComponentModel.DataAnnotations;

namespace PropertyShowingBookingApi.DTOs;

public class CreateSlotDto
{
    [Range(1, int.MaxValue)] public int PropertyId { get; set; }
    public DateTime StartsAt { get; set; }
    [Range(15, 120)] public int DurationMinutes { get; set; }
    [Range(1, 20)] public int Capacity { get; set; }
}
