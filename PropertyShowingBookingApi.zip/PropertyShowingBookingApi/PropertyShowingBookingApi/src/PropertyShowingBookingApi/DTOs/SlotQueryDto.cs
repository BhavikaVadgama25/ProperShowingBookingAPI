namespace PropertyShowingBookingApi.DTOs;

public class SlotQueryDto
{
    public int? PropertyId { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
