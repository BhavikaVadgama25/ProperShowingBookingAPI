using System.ComponentModel.DataAnnotations;

namespace PropertyShowingBookingApi.DTOs;

public class TransitionBookingDto
{
    [Required] public string To { get; set; } = "";
    [MaxLength(500)] public string? Reason { get; set; }
    [Required] public string Actor { get; set; } = "";
}
