namespace PropertyShowingBookingApi.Enums;

public enum BookingStatus
{
    Confirmed = 1,
    Cancelled = 2,
    Attended = 3,
    NoShow = 4
}
