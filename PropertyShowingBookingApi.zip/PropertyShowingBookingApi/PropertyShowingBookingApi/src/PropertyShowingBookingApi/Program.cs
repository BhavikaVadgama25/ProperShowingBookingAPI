
using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Data;
using PropertyShowingBookingApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(
        "Server=(localdb)\\MSSQLLocalDB;Database=TestDb;Trusted_Connection=True;TrustServerCertificate=True;"
    ));

builder.Services.AddScoped<BookingService>();

var app = builder.Build();

// Swagger Configuration
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "Property Showing Booking API V1");
    options.RoutePrefix = "swagger";
});

app.UseHttpsRedirection();

app.MapControllers();

// Default Root URL
app.MapGet("/", () => Results.Redirect("/swagger"));

app.Run();

public partial class Program { }
