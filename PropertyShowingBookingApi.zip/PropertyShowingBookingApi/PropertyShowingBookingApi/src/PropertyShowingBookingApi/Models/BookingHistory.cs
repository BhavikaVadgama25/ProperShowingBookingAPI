namespace PropertyShowingBookingApi.Models;

public class BookingHistory
{
    public int Id { get; set; }
    public int BookingId { get; set; }
    public string FromStatus { get; set; } = "";
    public string ToStatus { get; set; } = "";
    public string Actor { get; set; } = "";
    public string? Reason { get; set; }
    public DateTime ChangedAt { get; set; }
    public Booking Booking { get; set; } = null!;
}
