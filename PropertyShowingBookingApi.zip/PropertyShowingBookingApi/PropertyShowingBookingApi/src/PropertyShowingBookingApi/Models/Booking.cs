using PropertyShowingBookingApi.Enums;

namespace PropertyShowingBookingApi.Models;

public class Booking
{
    public int Id { get; set; }
    public int SlotId { get; set; }
    public string RenterEmail { get; set; } = "";
    public int PartySize { get; set; }
    public BookingStatus Status { get; set; } = BookingStatus.Confirmed;
    public DateTime CreatedAt { get; set; }
    public ShowingSlot Slot { get; set; } = null!;
    public ICollection<BookingHistory> History { get; set; } = new List<BookingHistory>();
}
