namespace PropertyShowingBookingApi.Models;

public class ShowingSlot
{
    public int Id { get; set; }
    public int PropertyId { get; set; }
    public DateTime StartsAt { get; set; }
    public int DurationMinutes { get; set; }
    public int Capacity { get; set; }
   public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
