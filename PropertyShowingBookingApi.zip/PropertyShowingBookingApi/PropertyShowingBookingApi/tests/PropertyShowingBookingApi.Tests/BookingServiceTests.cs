using Microsoft.EntityFrameworkCore;
using PropertyShowingBookingApi.Data;
using PropertyShowingBookingApi.DTOs;
using PropertyShowingBookingApi.Enums;
using PropertyShowingBookingApi.Models;
using PropertyShowingBookingApi.Services;
using Xunit;

namespace PropertyShowingBookingApi.Tests;

public class BookingServiceTests
{
    private static ApplicationDbContext CreateDb(string name)
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(name).Options;
        return new ApplicationDbContext(options);
    }

    [Fact]
    public async Task CreateBooking_RejectsWhenCapacityWouldBeExceeded()
    {
        await using var db = CreateDb(nameof(CreateBooking_RejectsWhenCapacityWouldBeExceeded));
        db.ShowingSlots.Add(new ShowingSlot
        {
            Id = 1, PropertyId = 10, StartsAt = DateTime.UtcNow.AddDays(1),
            DurationMinutes = 30, Capacity = 2
        });
        await db.SaveChangesAsync();
        var service = new BookingService(db);

        await service.CreateBookingAsync(1, new CreateBookingDto { RenterEmail = "a@test.com", PartySize = 2 }, default);

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            service.CreateBookingAsync(1, new CreateBookingDto { RenterEmail = "b@test.com", PartySize = 1 }, default));
        Assert.Contains("Not enough seats", ex.Message);
    }

    [Fact]
    public async Task Transition_CancellationChangesStatusAndWritesHistory()
    {
        await using var db = CreateDb(nameof(Transition_CancellationChangesStatusAndWritesHistory));
        var slot = new ShowingSlot
        {
            Id = 1, PropertyId = 10, StartsAt = DateTime.UtcNow.AddDays(1),
            DurationMinutes = 30, Capacity = 3
        };
        var booking = new Booking
        {
            Id = 1, SlotId = 1, RenterEmail = "a@test.com", PartySize = 1,
            Status = BookingStatus.Confirmed, CreatedAt = DateTime.UtcNow, Slot = slot
        };
        db.ShowingSlots.Add(slot);
        db.Bookings.Add(booking);
        await db.SaveChangesAsync();

        var result = await new BookingService(db).TransitionAsync(1,
            new TransitionBookingDto { To = "Cancelled", Actor = "renter", Reason = "Changed plans" }, default);

        Assert.Equal(BookingStatus.Cancelled, result.Status);
        Assert.Single(await db.BookingHistories.ToListAsync());
    }

    [Fact]
    public async Task Transition_DoesNotAllowRenterToMarkAttended()
    {
        await using var db = CreateDb(nameof(Transition_DoesNotAllowRenterToMarkAttended));
        var slot = new ShowingSlot
        {
            Id = 1, PropertyId = 10, StartsAt = DateTime.UtcNow.AddMinutes(-5),
            DurationMinutes = 30, Capacity = 3
        };
        db.ShowingSlots.Add(slot);
        db.Bookings.Add(new Booking
        {
            Id = 1, SlotId = 1, RenterEmail = "a@test.com", PartySize = 1,
            Status = BookingStatus.Confirmed, CreatedAt = DateTime.UtcNow, Slot = slot
        });
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            new BookingService(db).TransitionAsync(1,
                new TransitionBookingDto { To = "Attended", Actor = "renter" }, default));
    }
}
